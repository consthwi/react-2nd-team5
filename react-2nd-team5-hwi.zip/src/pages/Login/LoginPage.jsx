import React from "react";

const LoginPage = () => {
  return <div>LoginPage Rendering</div>;
};

export default LoginPage;
