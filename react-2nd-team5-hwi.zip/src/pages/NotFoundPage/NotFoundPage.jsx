import React from "react";

const NotFoundPage = () => {
  return <div>NotFound Rendering</div>;
};

export default NotFoundPage;
